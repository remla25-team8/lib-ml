# lib-ml
This library includes the preprocessing logic for the Restaurant Sentiment Analysis project, for use by the model-training and model-service components.

## Installation
```bash
pip install git+https://github.com/remla25-teamX/remla25-teamX-lib-ml.git@vX.Y.Z